#pragma once
#include<memory>
#include"ServiceManager.h"
namespace antipc{class Kernel{std::unique_ptr<ServiceManager> sm;public:Kernel();bool boot();void run();void shutdown();};}
