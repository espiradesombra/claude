#pragma once
#include "../core/Result.h"
namespace antipc{class IService{public:virtual ~IService()=default;virtual Result initialize()=0;virtual void update()=0;virtual void shutdown()=0;};}
