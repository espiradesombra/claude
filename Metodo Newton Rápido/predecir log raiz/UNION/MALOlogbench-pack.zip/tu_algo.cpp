#include "tu_algo.hpp"
#include <algorithm>

static inline double clamp(double x, double lo, double hi){ return std::min(std::max(x,lo),hi); }

// Log_b(a): doble ajuste simultáneo con parámetros optimizados
double tu_log_b_a(double a, double b){
    if(!(a>0.0) || !(b>0.0) || b==1.0) return std::numeric_limits<double>::quiet_NaN();

    const double f1=1.2, f2=3.4, f3=-0.8, f4=1.9; // f5,f6 omitidos aquí para simplicidad del ejemplo
    double j=1.0, d2=0.0, d1=0.0;
    const double precision=1e-15;

    for(int it=0; it<15; ++it){
        double bj = std::pow(b, j);
        if (a/bj >= bj){ j *= f1; continue; }

        double j1 = j;
        double d3 = d2; d2 = d1;

        j = (a + (a/std::pow(b, j)) - 1.0)/a;

        d1 = j - j1;
        j *= (1.0 + f2*std::abs(d1));

        if (std::abs(d3 - d1) > 1e-12){
            double factor = (f3 + f4*(d3 - d2)/(d3 - d1));
            double expo = std::min(std::abs(factor), 2.0);
            j = std::pow(std::abs(j), expo);
        }
        if (std::abs(j - j1) < precision) break;
    }
    return j;
}

// Raíz n-ésima: x^n ≈ a, usando error logarítmico para estabilidad
double tu_root(double a, double n){
    if(!(a>=0.0) || !(n>0.0)) return std::numeric_limits<double>::quiet_NaN();
    if(a==0.0) return 0.0;
    const double f1=1.2, f2=3.4, f3=-0.8, f4=1.9;
    double x = std::max( std::exp(std::log(a)/n), 1e-300 );
    const double precision = 1e-15;

    for(int it=0; it<20; ++it){
        double ex = n*std::log(std::max(x, 1e-300));
        double err = ex - std::log(a);
        double x1 = x;

        double corr = (err==0.0) ? 0.0 : -err/(n);
        x = x * std::exp(corr);

        double d = x - x1;
        x *= (1.0 + f2*std::abs(d)/std::max(std::abs(x1),1e-300));
        double trend = (std::abs(d)>1e-18) ? clamp(d/x, -1.0, 1.0) : 0.0;
        double expo = std::min(std::abs(f3 + f4*trend), 2.0);
        x = std::pow(std::abs(x), expo);

        if (std::abs(x - x1) < precision*std::max(1.0,std::abs(x1))) break;
        x = std::max(x, 1e-300);
    }
    return x;
}
