"""AntiPC plugins."""

from .k3_plugin import K3HashPlugin

__all__ = ["K3HashPlugin"]