#include"Kernel.h"
#include<iostream>
using namespace antipc;Kernel::Kernel():sm(std::make_unique<ServiceManager>()){}bool Kernel::boot(){std::cout<<"Boot\n";return sm->initialize()==Result::Ok;}void Kernel::run(){sm->update();}void Kernel::shutdown(){sm->shutdown();std::cout<<"Shutdown\n";}
