#pragma once
#include<vector>
#include<memory>
#include"IService.h"
namespace antipc{class ServiceManager{std::vector<std::unique_ptr<IService>> s;public:Result initialize();void update();void shutdown();};}
