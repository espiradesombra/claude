
#include "tu_algo.hpp"
#include <algorithm>
#include <cmath>
#include <limits>

static inline double clamp(double x, double lo, double hi) {
    return std::min(std::max(x, lo), hi);
}

double tu_log_b_a(double a, double b) {
    if (!(a > 0.0) || !(b > 0.0) || b == 1.0) return std::numeric_limits<double>::quiet_NaN();
    if (a == 1.0) return 0.0; // Caso especial

    const double factor1 = 1.3;
    const double factor2 = 3.4;
    const double factor3 = -0.8;
    const double factor4 = 1.9;
    const double factor5 = -0.8;
    const double factor6 = 1.9;

    double j = 1.0;
    double d3 = 0.0, d2 = 0.0, d1 = 0.0;
    const double precision = 1e-5;
    const double limite_inferior = 1e-5;

    for (int iteracion = 0; iteracion < 50; ++iteracion) { // Aumenté iteraciones
        double potencia = std::pow(b, j);
        
        // Prevención de overflow/underflow
        if (std::isinf(potencia) || potencia == 0.0) {
            j *= 0.5;
            continue;
        }
        if (a / std::pow(b, j) >= std::pow(b, j)) {
            j *= factor1;
            continue;
        }

        double j_previo = j;
        
        // Fórmula principal CORREGIDA
        j *= (a + (a / potencia) - 1.0) / a;

        d3 = d2;
        d2 = d1;
        d1 = j - j_previo;

        // Ajuste multiplicativo
        j *= (1.0 + factor2 * std::abs(d1));

        // Ajuste exponencial 1
        if (std::abs(d3 - d1) > limite_inferior && d3 != d1) {
            double factor_exp1 = factor3 + factor4 * (d3 - d2) / (d3 - d1);
            j = std::copysign(std::pow(std::abs(j), std::abs(factor_exp1)), j);
        }

        j_previo = j;
        potencia = std::pow(b, j);
        if (std::isinf(potencia) || potencia == 0.0) break;
        
        j *= (a + (a / potencia) - 1.0) / a;

        d3 = d2;
        d2 = d1;
        d1 = j - j_previo;

        // Ajuste exponencial 2
        if (std::abs(d3 - d1) > limite_inferior && d3 != d1) {
            double factor_exp2 = factor5 + factor6 * (d3 - d2) / (d3 - d1);
            j = std::copysign(std::pow(std::abs(j), std::abs(factor_exp2)), j);
        }

        if (std::abs(j - j_previo) < precision) break;
    }
    return j;
}

double tu_root(double a, double n) {
    if (!(a >= 0.0) || !(n > 0.0)) return std::numeric_limits<double>::quiet_NaN();
    if (a == 0.0) return 0.0;
    if (a == 1.0) return 1.0;

    const double factor1 = 1.2;
    const double factor2 = 3.4;
    const double factor3 = -0.8;
    const double factor4 = 1.9;
    const double factor5 = -0.8;
    const double factor6 = 1.9;

    // Mejor inicialización
    double x = (a > 1.0) ? a : 1.0;
    double d3 = 0.0, d2 = 0.0, d1 = 0.0;
    const double precision = 1e-15;
    const double limite_inferior = 1e-12;

    for (int iteracion = 0; iteracion < 50; ++iteracion) {
        double potencia = std::pow(x, n);
        
        if (std::isinf(potencia) || potencia == 0.0) {
            x *= 0.5;
            continue;
        }

        double x_previo = x;
        
        // FÓRMULA CORREGIDA - multiplicar por x
        x = x * (a + (a / potencia) - 1.0) / a;

        d3 = d2;
        d2 = d1;
        d1 = x - x_previo;

        // Ajustes
        x *= (1.0 + factor2 * std::abs(d1));

        if (std::abs(d3 - d1) > limite_inferior && d3 != d1) {
            double factor_exp1 = factor3 + factor4 * (d3 - d2) / (d3 - d1);
            x = std::copysign(std::pow(std::abs(x), std::abs(factor_exp1)), x);
        }

        x_previo = x;
        potencia = std::pow(x, n);
        if (std::isinf(potencia) || potencia == 0.0) break;
        
        x = x * (a + (a / potencia) - 1.0) / a;

        d3 = d2;
        d2 = d1;
        d1 = x - x_previo;

        if (std::abs(d3 - d1) > limite_inferior && d3 != d1) {
            double factor_exp2 = factor5 + factor6 * (d3 - d2) / (d3 - d1);
            x = std::copysign(std::pow(std::abs(x), std::abs(factor_exp2)), x);
        }

        if (std::abs(x - x_previo) < precision * std::max(1.0, std::abs(x_previo))) break;
        
        x = clamp(x, 1e-300, 1e+300);
    }
    return x;
}