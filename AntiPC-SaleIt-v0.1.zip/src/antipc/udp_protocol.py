"""Binary UDP protocol for AntiPC hub ↔ master communication."""

from __future__ import annotations

import struct
from enum import IntEnum

HEADER = struct.Struct("!B I H")  # type, seq, payload_len
RESULT = struct.Struct("!B I I")  # type, seq, hash
DONE = struct.Struct("!B")        # type


class MsgType(IntEnum):
    WORK = 0x01
    RESULT = 0x02
    DONE = 0x03
    PING = 0x04
    PONG = 0x05


def pack_work(seq: int, payload: bytes) -> bytes:
    return HEADER.pack(MsgType.WORK, seq, len(payload)) + payload


def unpack_work(data: bytes) -> tuple[int, bytes]:
    msg_type, seq, length = HEADER.unpack_from(data)
    if msg_type != MsgType.WORK:
        raise ValueError(f"expected WORK, got {msg_type}")
    start = HEADER.size
    return seq, data[start : start + length]


def pack_result(seq: int, digest: int) -> bytes:
    return RESULT.pack(MsgType.RESULT, seq, digest & 0xFFFFFFFF)


def unpack_result(data: bytes) -> tuple[int, int]:
    msg_type, seq, digest = RESULT.unpack_from(data)
    if msg_type != MsgType.RESULT:
        raise ValueError(f"expected RESULT, got {msg_type}")
    return seq, digest


def pack_done() -> bytes:
    return DONE.pack(MsgType.DONE)


def pack_ping() -> bytes:
    return DONE.pack(MsgType.PING)


def pack_pong() -> bytes:
    return DONE.pack(MsgType.PONG)