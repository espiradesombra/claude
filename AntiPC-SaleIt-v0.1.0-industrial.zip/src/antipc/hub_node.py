#!/usr/bin/env python3
"""AntiPC UDP hub worker — lock-free ring buffer + K3 HASH pipeline."""

from __future__ import annotations

import argparse
import os
import socket
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from hash_engine import k3_hash_buffer
from ring_buffer import SPSCRingBuffer
from udp_protocol import (
    MsgType,
    pack_pong,
    pack_result,
    unpack_work,
    HEADER,
    DONE,
)


def _heavy_hash(payload: bytes) -> int:
    digest = k3_hash_buffer(payload)
    for _ in range(4):
        digest = k3_hash_buffer(digest.to_bytes(4, "little") + payload)
    return digest


def run_hub(port: int, master_addr: tuple[str, int], verbose: bool = False) -> None:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", port))
    sock.settimeout(0.001)

    ring: SPSCRingBuffer[tuple[int, bytes, tuple[str, int]]] = SPSCRingBuffer(8192)
    cache: dict[int, int] = {}
    processed = 0
    cache_hits = 0
    running = True

    if verbose:
        print(f"[hub:{port}] listening, master={master_addr}", flush=True)

    while running:
        # ingest UDP → ring (zero extra copy beyond recv buffer slice)
        try:
            data, addr = sock.recvfrom(65535)
        except (BlockingIOError, TimeoutError, OSError):
            data = b""

        if data:
            if len(data) == DONE.size and data[0] == MsgType.DONE:
                running = False
                continue
            if len(data) == DONE.size and data[0] == MsgType.PING:
                sock.sendto(pack_pong(), master_addr)
                continue
            if len(data) >= HEADER.size and data[0] == MsgType.WORK:
                seq, payload = unpack_work(data)
                while not ring.push((seq, payload, addr)):
                    pass

        # worker: ring → HASH → RESULT
        item = ring.pop()
        if item is None:
            time.sleep(0)
            continue

        seq, payload, reply_addr = item
        key = k3_hash_buffer(payload)
        if key in cache:
            digest = cache[key]
            cache_hits += 1
        else:
            digest = _heavy_hash(payload)
            cache[key] = digest
        sock.sendto(pack_result(seq, digest), reply_addr)
        processed += 1

    sock.close()
    if verbose:
        print(f"[hub:{port}] done processed={processed} cache_hits={cache_hits}", flush=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="AntiPC UDP hub")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--master-host", default="127.0.0.1")
    parser.add_argument("--master-port", type=int, default=19700)
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()
    run_hub(args.port, (args.master_host, args.master_port), args.verbose)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())