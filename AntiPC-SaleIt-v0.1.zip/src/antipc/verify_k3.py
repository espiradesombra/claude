#!/usr/bin/env python3
"""Cross-check Python K3 port against compiled k3hash.dll if available."""

from __future__ import annotations

import ctypes
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from k3_hash import k3_hash_buffer, K3HashConfig

K3_SRC = r"C:\Users\cuent\Desktop\vma\c\k3hash"
DLL_PATH = os.path.join(os.path.dirname(__file__), "k3hash.dll")


def _try_compile_dll() -> bool:
    src = os.path.join(K3_SRC, "src", "k3hash.c")
    if not os.path.isfile(src):
        return False
    cmd = (
        f'gcc -shared -O2 -DK3HASH_BUILD_SHARED '
        f'-I"{os.path.join(K3_SRC, "include")}" '
        f'"{src}" -o "{DLL_PATH}"'
    )
    return os.system(cmd) == 0 and os.path.isfile(DLL_PATH)


def _hash_via_dll(data: bytes) -> int | None:
    if not os.path.isfile(DLL_PATH):
        return None
    lib = ctypes.CDLL(DLL_PATH)

    class K3HashConfig(ctypes.Structure):
        _fields_ = [
            ("bits_ancho", ctypes.c_int),
            ("num_registros", ctypes.c_int),
            ("semilla_inicial", ctypes.c_uint32),
        ]

    lib.k3_config_default.restype = K3HashConfig
    lib.k3_hash_buffer.argtypes = [
        ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(K3HashConfig)
    ]
    lib.k3_hash_buffer.restype = ctypes.c_uint32

    cfg = lib.k3_config_default()
    buf = ctypes.create_string_buffer(data, len(data))
    return int(lib.k3_hash_buffer(buf, len(data), ctypes.byref(cfg)))


def main() -> int:
    samples = [
        b"",
        b"AntiPC",
        b"x^=(B*0x9E3779B1);",
        os.urandom(128),
    ]

    if not os.path.isfile(DLL_PATH):
        print("  Compiling k3hash.dll...")
        if not _try_compile_dll():
            print("  gcc not available — Python port only (no cross-check).")
            for s in samples:
                print(f"    py({s[:20]!r}...) = {k3_hash_buffer(s):08X}")
            return 0

    ok = True
    for sample in samples:
        py_h = k3_hash_buffer(sample)
        c_h = _hash_via_dll(sample)
        match = py_h == c_h
        ok = ok and match
        label = "OK" if match else "MISMATCH"
        print(f"  [{label}] py={py_h:08X}  c={c_h:08X}  len={len(sample)}")

    print()
    print("  K3 Python port verified against k3hash.c" if ok else "  MISMATCH detected")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())