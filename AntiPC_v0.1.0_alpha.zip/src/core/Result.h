#pragma once
namespace antipc{enum class Result{Ok,Error};}
