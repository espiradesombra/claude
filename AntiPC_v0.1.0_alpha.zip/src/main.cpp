#include "kernel/Kernel.h"
int main(){antipc::Kernel k; if(!k.boot()) return 1; k.run(); k.shutdown();}
