#include"ServiceManager.h"
using namespace antipc;Result ServiceManager::initialize(){return Result::Ok;}void ServiceManager::update(){}void ServiceManager::shutdown(){}
